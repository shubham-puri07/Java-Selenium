
public class FirstJavaProgram {
	
	static int varSec = 98765;
	
	public static void firstMethod(){
		
		int number = 12345;
		
		boolean flag = true;
		char character = 'A';
		String city = "newyork";
		
		long phonenumber = 9876543215L;
		
		double decimalvalue = 234.43D;
		
		System.out.println(number);
		System.out.println(city);
		System.out.println(varSec);
		
	}

	public static void main(String[] args) {
		FirstJavaProgram.firstMethod();
	    System.out.println(varSec);

	}

}
