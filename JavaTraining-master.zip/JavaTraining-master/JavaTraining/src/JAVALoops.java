
public class JAVALoops {

	public static void main(String[] args) {
		
		for (int i = 0; i < 15; i++) {
			System.out.println(i);
			
		}
		
		int i = 0;
		
		while (i<=10) {
			System.out.println(i);
		i++;	
		}
		
		while(true){
			System.err.println(i);
			i++;
		}

	}

}
