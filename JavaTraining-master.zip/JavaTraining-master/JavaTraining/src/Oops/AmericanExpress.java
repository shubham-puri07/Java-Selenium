package Oops;

public class AmericanExpress extends Bank{
	
	public int getInterest(){
		return 8;
	}

}
