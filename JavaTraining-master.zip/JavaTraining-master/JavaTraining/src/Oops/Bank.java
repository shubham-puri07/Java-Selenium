package Oops;

public class Bank {
	
	public int getInterest(){
		return 0;
	}

}
