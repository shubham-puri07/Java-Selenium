package Oops;

public class BankOfAmerica extends Bank {
	
	public int getInterest(){
		return 7;
	}

}
