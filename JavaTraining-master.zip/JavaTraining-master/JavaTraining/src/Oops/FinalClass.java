package Oops;

public  final class FinalClass {

}
