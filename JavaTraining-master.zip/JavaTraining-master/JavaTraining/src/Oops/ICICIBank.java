package Oops;

public class ICICIBank extends Bank {
	
	public int getInterest(){
		return 9;
	}

}
