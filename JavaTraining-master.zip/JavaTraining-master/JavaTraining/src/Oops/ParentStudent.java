package Oops;

public interface ParentStudent {
	
	public void getInterfaceName();

}
