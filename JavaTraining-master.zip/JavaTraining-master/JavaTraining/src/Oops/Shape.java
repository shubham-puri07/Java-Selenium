package Oops;

abstract public class Shape {
	
	abstract public void displayShape();
	
	public void dislayName(){
		System.out.println("From Shape Class");
	}

}
