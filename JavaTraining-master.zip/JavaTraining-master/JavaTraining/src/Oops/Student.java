package Oops;

public interface Student extends ParentStudent{
	
	public static final String university = "University of New York";
	
	public void displayName();
	
	public void getStudentNumber();
	
	public void getStandard();
	

}
