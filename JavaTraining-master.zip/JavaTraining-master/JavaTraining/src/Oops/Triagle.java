package Oops;

public class Triagle extends Shape{

	
	public void displayShape() {
		System.out.println("Shape is Triagle");
		
	}

}
