package String;

public class StringMethodPartII {

	public static void main(String[] args) {
		
		String text1 = "TechTraining";
		
		/*String text2 = "TechTraining";
		
		String text3 = "techtraining";
		
		System.out.println(text1.equals(text2));
		System.out.println(text1.equals(text3));
		
		System.out.println(text1.equalsIgnoreCase(text3));*/
		
		//.out.println(text1.indexOf("h"));
		
		//System.out.println(text1.lastIndexOf("i"));

		System.out.println(text1.length());
	}

}
