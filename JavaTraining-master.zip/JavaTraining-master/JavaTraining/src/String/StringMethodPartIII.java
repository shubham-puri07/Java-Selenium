package String;

public class StringMethodPartIII {

	public static void main(String[] args) {
		
		//String text = "Hello Team";
		String sample = "His name is John and he is a good man";
		
		/*String text1 = text.replace("e", "a");
		String sample2 = sample.replace("is", "was");
		
		System.out.println(text1);
		System.out.println(sample2);
*/
		/*String[] sampletest = sample.split("John");
		
		System.out.println(sample);
		
		for (int i = 0; i < sampletest.length; i++) {
			System.out.println(sampletest[i]);
		}*/
		
		System.out.println(sample.startsWith("name"));
	}
}
