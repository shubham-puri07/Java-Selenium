
import org.testng.annotations.Test;

public class FaceBookProfileTest {

	@Test
	public void checkProfileLink(){
		System.out.println("Profile Link is fine");
	}

	@Test
	public void checkProfileLogo(){
		System.out.println("Profile Logo is fine");
	}

}
