package com.testng.training;

import org.testng.annotations.Test;

public class SamplClassTwo {

	@Test
	public void sampleTestTwoMethodOne(){
		System.out.println("Hi, I am from Sample Class Two, Method One");
	}

	@Test
	public void sampleTestTwoMethodTwo(){
		System.out.println("Hi, I am from Sample Class Two, Method Two");
	}

}
