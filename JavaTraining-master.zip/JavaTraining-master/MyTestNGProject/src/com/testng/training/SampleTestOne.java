package com.testng.training;

import org.testng.annotations.Test;

public class SampleTestOne {

	@Test
	public void sampleTestOneMethodOne(){
		System.out.println("Hi, I am from Sample Class One, Method One");
	}

	@Test
	public void sampleTestOneMethodTwo(){
		System.out.println("Hi, I am from Sample Class One, Method Two");
	}

}
