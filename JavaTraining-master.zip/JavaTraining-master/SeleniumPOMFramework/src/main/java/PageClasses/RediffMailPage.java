package PageClasses;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import baseClasses.PageBaseClass;

public class RediffMailPage extends PageBaseClass{
	
	
	public RediffMailPage(WebDriver driver, ExtentTest logger){
		super(driver, logger);
	}
	
	//WebElements of RediffMail Page
	//Operation of Rediffmail Page
	
	public void clickWriteEmail(){
		//Write Mail
	}
	
	public void typeMail(){
		//mail Tying
	}

public void getTitle(){
		
	}
}
