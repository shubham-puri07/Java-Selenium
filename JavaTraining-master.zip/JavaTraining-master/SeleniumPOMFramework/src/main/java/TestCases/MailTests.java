package TestCases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import PageClasses.LandingPage;
import PageClasses.RediffMailPage;

public class MailTests {
	
//	@Test
//	public void writeMailTest(){
//		
//		LandingPage landingPage = new LandingPage();
//		landingPage.getTitle();
//		landingPage.openBrowser();
//		landingPage.openWebSite();
//		LoginPage loginPage = landingPage.clickSingIn();
//		loginPage.getTitle();
//		RediffMailPage rediffmailPage = loginPage.doLogin();
//		rediffmailPage.getTitle();
//	}

}
