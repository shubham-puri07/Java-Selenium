package utilities;

public class ConstantValue {
	
	public static final String userName="anshulc55";
	public static final String password="Test@1234";

}
